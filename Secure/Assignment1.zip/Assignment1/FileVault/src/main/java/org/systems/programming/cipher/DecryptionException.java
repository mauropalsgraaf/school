package org.systems.programming.cipher;

public class DecryptionException extends Exception {

    public DecryptionException(String message) {
        super(message);
    }
}
