package org.systems.programming.cipher;

public class EncryptionException extends Exception {

    public EncryptionException(String exception) {
        super(exception);
    }
}
